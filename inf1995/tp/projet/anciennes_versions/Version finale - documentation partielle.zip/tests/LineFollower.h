#ifndef LineFollower_H
#define LineFollower_H

  #include "lib_dir/Settings.h"
  #include "lib_dir/PulseWidthModulation.h"
  #include "lib_dir/Util.h"

  namespace Sensor {
    enum Sensor {
      EXTREM_LEFT = 0x80, LEFT = 0x40, CENTER = 0x20, RIGHT = 0x10, EXTREM_RIGHT = 0x08
    };
  }

  bool isDetecting(Sensor::Sensor sensor);

  class LineFollower {

  public:
    LineFollower();
    ~LineFollower();

    bool followLine(bool twist);
    bool followLine(uint8_t distanceToWall, bool twist);

    bool uTurn();
    void rightTurn();
    void leftTurn();

    void stop();

  private:
    void ajustTrack(uint8_t percentage, bool twist);

    bool isOnLine; // true quand capteur C3 détecte ligne
    uint8_t rotationStage;

    uint8_t normalRightSpeed;
    uint8_t normalLeftSpeed;
    uint8_t rightSpeed;
    uint8_t leftSpeed;

  };

#endif // ! LineFollower_H
