#include "lib_dir/Settings.h"
#include "lib_dir/Util.h"
#include "lib_dir/Minuterie.h"
#include "lib_dir/PulseWidthModulation.h"
#include "lib_dir/Dell.h"
#include "ColorDetector.h"
#include "SuiveurDeLigne.h"
#include "Forme.h"
#include "Color.h"

volatile bool tick = false;
volatile uint16_t nCycles = 0;

// Minuterie au 5 millisecondes
ISR(TIMER1_COMPA_vect){
  tick = true;
}

ISR(INT0_vect){
	nCycles++;
}

int main()
{
  initialisation();
  initialiserMinuterie(5);
  //Piece::Piece suitePiece[3] = {Piece::CARRE, Piece::CERCLE, Piece::OCTOGONE};// Rouge vert bleu

  ColorDetector colorDetector;
  int calibration = 205;

//  Color::Color color = Color::WHITE;

  PORTD |= 0x01;

  while (true) {
    if (tick) {
      tick = false;

      if (calibration > 200) {
        calibration--;
        colorDetector.calibrateFrequency(nCycles);

      } else if (calibration > 0) {
        calibration--;
        PORTD &= ~(0x01);
      } else {
        PORTD |= 0x01;
        colorDetector.addSample(nCycles);
      }


      switch (colorDetector.getColor()) {
          case Color::RED:
          setLight(Couleur::Rouge);
          soundOff();
          break;
          case Color::GREEN:
          setLight(Couleur::Vert);
          soundOff();
          break;
          case Color::BLUE:
          setLight(Couleur::Eteint);
          soundOn(69);
          break;
          case Color::WHITE:
          setLight(Couleur::Eteint);
          soundOff();
          break;
          default:
          break;
      }

      nCycles = 0;
    }
  }
  while (true) {
    /* code */
  }
  return 0;
}
