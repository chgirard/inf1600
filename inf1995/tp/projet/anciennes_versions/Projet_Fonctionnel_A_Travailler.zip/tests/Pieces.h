#ifndef PIECES_H
#define PIECES_H

namespace Piece {
  enum Piece {
    CARRE, CERCLE, OCTOGONE, UNKNOWN
  };
}

#endif /* Pieces_h */
