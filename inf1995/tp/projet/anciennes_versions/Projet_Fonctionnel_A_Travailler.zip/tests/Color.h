#ifndef COLOR_H
#define COLOR_H

namespace Color {
  enum Color {
  	WHITE, RED, GREEN, BLUE
  };
}

#endif
