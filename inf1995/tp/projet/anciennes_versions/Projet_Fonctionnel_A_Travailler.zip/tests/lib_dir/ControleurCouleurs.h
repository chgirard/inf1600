#ifndef CONTROLEUR_COULEURS_H
#define CONTROLEUR_COULEURS_H

/////////////////////////////////
// s0 | s1 : min/typ
//  0 |  0 : --Power down--
//  0 |  1 :  10/12  kHz
//  1 |  0 : 100/120 kHz
//  1 |  1 : 500/600 kHz
/////////////////////////////////
// s2 | s3 : filtre
//  0 |  0 : rouge
//  0 |  1 : bleu
//  1 |  0 : --aucun--
//  1 |  1 : vert
/////////////////////////////////

// Ces couleurs valent respectivement
//      0,    1,     2,    3
enum couleur{
	CLAIR, ROUGE, VERT, BLEU
};

class ControleurCouleurs {

public:

	/*
	 *  Constructeur du contrôleur de couleurs.
	 * \param [in] suiteFormes  La suite des formes enregistrée par le robot
	 *                          et qui doit correspondre à celle des couleurs.
	 */
	ControleurCouleurs();

	/*
	 *  Destructeur du contrôleur de couleurs.
	 */
	~ControleurCouleurs();

	/*
	 *  Accès au nombre de cycles.
	 * \return Ledit nombre de cycles.
	 */
	int obtenirNCycles() const;

	/*
	 *  Accès à la couleur pointée.
	 * \return Ladite couleur.
	 */
	int obtenirCouleur() const;

	/*
	 *  Accès au filtre.
	 * \return Ledit filtre.
	 */
	int obtenirFiltre() const;

	/*
	 *  Change la couleur par celle prise en paramètre.
	 * \param [in] couleur  La couleur qui est détectée.
	 * \return void
	 */
	void modifierCouleur(int couleur);


	//TODO Description
 	void appliquerFiltre();

	/*
	 *  Fonction qui est appelée à tous les 5ms et qui gère les couleurs
	 * \return void
	 */
	void detecterCouleur(int nCycles);


	/*
	 *  Incrémente le nombre de cycles.
	 * \return void
	 */
	void incrementerFiltre();
	bool tick(int nCycles);

private:

	int filtre_;  // Filtre sur le capteur.
	int couleur_; // Dernière couleur détectée.


	bool estFini_; // Si on a détecté les trois bonnes couleurs consécutives.?

	/*
	 *  Push la nouvelle couleur détectée dans le tableau
	 * \return void
	 */
	void pushCouleur();

	/*
	 *  Compare si la suite de couleurs correspond à celle des formes.
	 * \return Si les suites correspondent.
	 */
	bool comparerSuites();


	/*
	 *  Incrémente le nombre de cycles.
	 * \return void
	 */
	void incrementerCycles();

	/*
	 *  Remise à zéro du nombre de cycles.
	 * \return void
	 */
	void razNCycles();

};


#endif // CONTROLEUR_COULEURS_H
