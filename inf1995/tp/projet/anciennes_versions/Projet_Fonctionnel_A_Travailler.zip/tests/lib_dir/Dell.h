#ifndef DELL_H
#define DELL_H

  #include "Settings.h"

  namespace Couleur {
    /**
    * @brief Differentes couleurs possibles de la dell
    *
    * Les valeurs qui leurs sont attribués sont pour aider lorsque la couleur est
    * fixée.
    */
    enum Couleur {
        Eteint, Vert, Rouge
    };
  }

  /**
   * @brief Change la couleur de la dell ea la couleur desiree
   * @param couleur Couleur desiree de la dell
   *
   * Le changement de couleur se fait aux ports PC0 et PC1
   */
  void setLight(Couleur::Couleur couleur);

#endif // !DELL_H
