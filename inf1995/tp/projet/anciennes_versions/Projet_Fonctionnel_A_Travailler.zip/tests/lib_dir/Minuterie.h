#ifndef MINUTERIE_H
#define MINUTERIE_H

#include "Settings.h"
#include "Prescaler.h"

/**
 * @brief Commence une minuterie qui fera des interruptions après un certain temps
 * @param ms Nombre de milisecondes de la minuterie
 */
void initialiserMinuterie(uint16_t ms);

/**
 * @brief Ajuste un compteur
 * @param duree Valeur de la comparaison avec le compteur pour lancer l'interruption
 */
void initialiserCompteur(uint16_t duree);

/**
 * @brief Ajuste un compteur
 * @param duree Valeur de la comparaison avec le compteur pour lancer l'interruption
 * @param prescaler Prescaler qui faut defenir au compteur
 * description:
   // mode CTC du timer 1 avec horloge divisee par le prescaler
   // interruption apres la duree specifiee
 */
void initialiserCompteur(uint16_t duree, Prescaler::Prescaler prescaler);

/**
 * @brief Ajuste le prescaler du compteur
 * @param prescaler Prescaler qui faut defenir au compteur
 */
void definirPrescaler(Prescaler::Prescaler prescaler);

/**
 *
 */
void arreterMinuterie();

#endif // !MINUTERIE_H
