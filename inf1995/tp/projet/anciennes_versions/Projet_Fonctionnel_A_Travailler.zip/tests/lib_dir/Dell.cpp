#include "Dell.h"

void setLight(Couleur::Couleur couleur) {
  // On utilise les PIN 2 et 3 pour le DEL
  // Eteint = 00
  // Vert = 01
  // Rouge = 10
  if (couleur & 0x01) { // set le PB2
    PORTB |= (0x01 << 0);
  } else {
    PORTB &= ~(0x01 << 0);
  }

  if (couleur & 0x02) { // set le PB3
    PORTB |= (0x01 << 1);
  } else {
    PORTB &= ~(0x01 << 1);
  }
}
