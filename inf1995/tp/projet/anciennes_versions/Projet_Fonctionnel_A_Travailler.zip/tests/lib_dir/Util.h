#ifndef LIBRAIRIE_H
#define LIBRAIRIE_H

#include "Settings.h"
#include "Sound.h"
#include "PulseWidthModulation.h"
/*
#include <avr/interrupt.h>
#include <util/delay.h>
#include <util/delay_basic.h>

#include "Dell.h"
#include "Direction.h"
#include "Roue.h"
#include "Prescaler.h"
*/
/**
 * @brief Effectue un delais de 10 ms pour l'anti-rebond
 */
bool debounce();

/**
 * @brief Verifie si le bouton est pese
 * @return true si le boutton est pese, false sinon
 */
bool isButtonPressed();

/**
 * @brief Initialise les entrees et sorties des differents ports de la carte mère
 * @param portA Valeurs d'entree ou de sortie du port A
 * @param portB Valeurs d'entree ou de sortie du port B
 * @param portC Valeurs d'entree ou de sortie du port C
 * @param portD Valeurs d'entree ou de sortie du port D
 */
void initialisation();

/**
 * @brief Retire les interruptions en queue d'execution
 */
void clairInterruptions();
void transmissionUART ( uint8_t donnee );
uint8_t ajusterValeur ( uint8_t valeur, uint8_t pourcentage );

#endif // ! LIBRAIRIE_H
