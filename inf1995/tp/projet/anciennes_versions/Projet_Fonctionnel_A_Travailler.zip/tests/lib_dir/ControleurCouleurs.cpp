#include "ControleurCouleurs.h"
#include "Sound.h"

/////////////////////////////////
// s0 | s1 : min/typ
//  0 |  0 : --Power down--
//  0 |  1 :  10/12  kHz
//  1 |  0 : 100/120 kHz
//  1 |  1 : 500/600 kHz
/////////////////////////////////
// s2 | s3 : filtre
//  0 |  0 : rouge
//  0 |  1 : bleu
//  1 |  0 : --aucun--
//  1 |  1 : vert
/////////////////////////////////
// couleur
// eteint : 0
// rouge  : 1
// vert   : 2
// bleu   : 3
/////////////////////////////////

//////////////////-CONST & DEST-//////////////////////
ControleurCouleurs::ControleurCouleurs()
	:filtre_(0), couleur_(0), estFini_(false)
{
}

ControleurCouleurs::~ControleurCouleurs()
{
}
//////////////////////////////////////////////////////
////////////////-MÉTHODES D'ACCÈS-////////////////////

int ControleurCouleurs::obtenirCouleur() const{
	return couleur_;
}

int ControleurCouleurs::obtenirFiltre() const{
	return filtre_;
}

//////////////////////////////////////////////////////
////////////-MÉTHODES DE MODIFICATION-////////////////

void ControleurCouleurs::incrementerFiltre(){
	if (filtre_ == BLEU){
		filtre_ = 0;
	} else {
		filtre_++;
	}

	appliquerFiltre();
}

void ControleurCouleurs::appliquerFiltre(){

	switch (filtre_){
	// On change le filtre en donction du nouveau filtre.
	case ROUGE:
		PORTC &= ~(1 << 2); // s2 = 0
		PORTC &= ~(1 << 3); // s3 = 0
		break;
	case VERT:
		PORTC |= (1 << 2); // s2 = 1
		PORTC |= (1 << 3); // s3 = 1
		break;
	case BLEU:
		PORTC &= ~(1 << 2); // s2 = 0
		PORTC |= (1 << 3); // s3 = 1
		break;
	case CLAIR:
		PORTC |= (1 << 2); // s2 = 1
		PORTC &= ~(1 << 3); // s3 = 0
		break;
	}
}

// Modification de la couleur.
void ControleurCouleurs::modifierCouleur(int couleur){
	couleur_ = couleur;
}



// Push la couleur nouvellement détectée.
void ControleurCouleurs::pushCouleur(){
}
//////////////////////////////////////////////////////

// Compare si la suite de couleurs correspond à celle des formes
// et met estFini à vrai au si c'est le cas.
bool ControleurCouleurs::comparerSuites(){
	// Si une paire couleur-forme diffère, on revoit faux.
	// Si toutes les paires couleur-formes sont égales, on renvoit vrai.
	return true;
}

bool ControleurCouleurs::tick(int nCycles){

}

void ControleurCouleurs::detecterCouleur(int nCycles){
	if (nCycles > 40){ // Si le seuil de détection est dépassé :
		// Et si la dernière couleur détectée n'est pas la couleur présentement détectée.
		if (couleur_ != filtre_){
			pushCouleur(); // Push de la couleur nouvellement détectée dans la suite.
		}
		modifierCouleur(filtre_); // La couleur devient celle du filtre.

		// On choisie également la réaction du robot en fonction du filtre.
		switch (couleur_){
		case ROUGE:             // Si rouge :
			PORTB |= (1 << 0);
			PORTB &= ~(1 << 1); // On allume la DEL en rouge.
			soundOff();
			break;
		case VERT:              // Si vert :
			PORTB &= ~(1 << 0);
			PORTB |= (1 << 1);  // On allume la DEL en vert
			soundOff();
			break;
		case BLEU:       // Si bleu :
			PORTB &= ~(1 << 0);
			PORTB &= ~(1 << 1);
			soundOn(69); // On émet un son aigu
			break;
		case CLAIR:
		default:
			PORTB |= (1 << 0);
			PORTB &= ~(1 << 0);
			soundOff();
			//remet tableau a 0;
			break;
		}

	}
	incrementerFiltre();
}
