#include "PulseWidthModulation.h"
#include "Dell.h"


void ajusterPWM(uint8_t ratio, Direction::Direction direction) {
  ajusterPWM(ratio, ratio, direction, direction);
}

void ajusterPWM(uint8_t ratioRoueGauche, uint8_t ratioRoueDroite, Direction::Direction direction) {
  ajusterPWM(ratioRoueGauche, ratioRoueDroite, direction, direction);
}

void ajusterPWM(uint8_t ratio, Direction::Direction directionRoueGauche, Direction::Direction directionRoueDroite) {
  ajusterPWM(ratio, ratio, directionRoueGauche, directionRoueDroite);
}

void ajusterPWM(uint8_t ratioRoueGauche, uint8_t ratioRoueDroite, Direction::Direction directionRoueGauche, Direction::Direction directionRoueDroite) {
    TCCR2A = 0;
    TCCR2B = 0;
  // mise a un des sorties OC1A et OC1B sur comparaison
  // reussie en mode PWM 8 bits, phase correcte
  // et valeur de TOP fixe a 0xFF (mode #1 de la table 16-5
  // page 130 de la description technique du ATmega324PA)
  TCCR2A |= (1 << WGM20 | 1 << COM2A1 | 1 << COM2B1) ;
    // division d'horloge par 8 - implique une frequence de PWM fixe
  TCCR2B |= (1 << CS11);

  OCR2A = ratioRoueDroite ;
  OCR2B = ratioRoueGauche ;

  ajusterDirection(Roue::Droite, directionRoueDroite);
  ajusterDirection(Roue::Gauche, directionRoueGauche);

}

void ajusterDirection(Roue::Roue roue, Direction::Direction direction) {
  switch (direction) {
    case Direction::Avancer:
      PORTD |= (1 << roue);
    break;
    case Direction::Reculer:
      PORTD &= ~(1 << roue);
    break;
  }

}
