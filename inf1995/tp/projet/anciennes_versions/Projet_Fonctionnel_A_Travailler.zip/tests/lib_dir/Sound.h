#ifndef SOUND_H
#define SOUND_H

#include "Settings.h"
#include "Prescaler.h"

void soundOn(uint8_t note);
void soundOff();
void initialiserCompteur0(uint8_t duree);
void initialiserCompteur0(uint8_t duree, Prescaler::Prescaler prescaler);
void definirPrescaler0(Prescaler::Prescaler prescaler);

#endif // !SOUND_H
