#include "Minuterie.h"


void initialiserMinuterie(uint16_t ms) {
  if (F_CPU <= 65536000L/ms)
  {
    initialiserCompteur(((uint32_t)ms)*8000, Prescaler::Prescaler_1);
  }
  else if (F_CPU <= 8*(65536000L/ms))
  {
    initialiserCompteur((((uint32_t)ms)*8000)/8, Prescaler::Prescaler_8);
  }
  else if (F_CPU <= 64*(65536000L/ms))
  {
    initialiserCompteur((((uint32_t)ms)*8000)/64, Prescaler::Prescaler_64);
  }
  else if (F_CPU <= 256*(65536000L/ms))
  {
    initialiserCompteur((((uint32_t)ms)*8000)/256, Prescaler::Prescaler_256);
  }
  else if (F_CPU <= 1024*(65536000L/ms))
  {
    initialiserCompteur((((uint32_t)ms)*8000)/1024, Prescaler::Prescaler_1024);
  }
  else
  {
    //throw error
  }
}

void initialiserCompteur(uint16_t duree) {
  initialiserCompteur(duree, Prescaler::Prescaler_1);
}

void initialiserCompteur(uint16_t duree, Prescaler::Prescaler prescaler) {
  TCNT1 = 0; // débute compteur à 0
  OCR1A = duree; // valeur de comparaison

  TCCR1A = 0;
  TCCR1B = 0;
  TCCR1C = 0;
  TCCR1B |= ((1 << WGM12)); //set CTC mode

  definirPrescaler(prescaler);
  TIMSK1 |= (1 << OCIE1A); // enable output compare timer1 with OCR1A
}

void definirPrescaler(Prescaler::Prescaler prescaler) {
  /*
  On définit les prescalers suivants en binaire:
                      CS12  CS11  CS10
    Prescaler_1     = 0     0     1
    Prescaler_8     = 0     1     0
    Prescaler_64    = 0     1     1
    Prescaler_256   = 1     0     0
    Prescaler_1024  = 1     0     1
    puis on les set bit par bit
  */
  if (prescaler & 0x01) { // set bit CS10
    TCCR1B |= (1 << CS10);
  } else {
    TCCR1B &= ~(1 << CS10);
  }

  if (prescaler & 0x02) { // set bit CS11
    TCCR1B |= (1 << CS11);
  } else {
    TCCR1B &= ~(1 << CS11);
  }

  if (prescaler & 0x04) { // set bit CS12
    TCCR1B |= (1 << CS12);
  } else {
    TCCR1B &= ~(1 << CS12);
  }
}

void arreterMinuterie() {
  TIMSK1 &= ~(1 << OCIE1A); // arrêter les interruptions déclenchées par OCR1A
}
