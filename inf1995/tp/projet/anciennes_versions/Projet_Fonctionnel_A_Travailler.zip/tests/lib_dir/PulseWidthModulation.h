#ifndef PULSE_WIDTH_MODULATION_H
#define PULSE_WIDTH_MODULATION_H

#include "Settings.h"

  namespace Roue {
    /**
     * @brief Défini les deux roues du robot. Les valeurs qui leurs sont attribués sont pour aider lorsque la direction de rotation des roue est fixée.
     */
    enum Roue {
        Gauche = 4, Droite = 5
    };
  }

  namespace Direction {
    /**
     * @brief Differents sens de rotation possible de la roue
     */
    enum Direction {
        Avancer, Reculer
    };
  }


  /**
   * @brief Ajuste le PWM au ratio desire
   * @param ratio Valeur du ratio deeire
   * @param direction Sens de la rotation des roues deeire
   */
  void ajusterPWM(uint8_t ratio, Direction::Direction direction);

  /**
   * @brief Ajuste le PWM au ratio desire
   * @param ratioRoueDroite Valeur du ratio de la roue droite desire
   * @param ratioRoueGauche Valeur du ratio de la roue gauche desire
   * @param direction Sens de la rotation des roues deeire
   */
  void ajusterPWM(uint8_t ratioRoueGauche, uint8_t ratioRoueDroite, Direction::Direction direction);
  void ajusterPWM(uint8_t ratio, Direction::Direction directionRoueGauche, Direction::Direction directionRoueDroite);

  /**
   * @brief Ajuste le PWM au ratio desire
   * @param ratioRoueDroite Valeur du ratio de la roue droite desire
   * @param ratioRoueGauche Valeur du ratio de la roue gauche desire
   * @param directionRoueDroite Sens de la rotation de la roue droite deeire
   * @param directionRoueGauche Sens de la rotation de la roue gauche deeire
   */
  void ajusterPWM(uint8_t ratioRoueGauche, uint8_t ratioRoueDroite, Direction::Direction directionRoueGauche, Direction::Direction directionRoueDroite);

  /**
   * @brief Ajuste le sens de rotation de la roue
   * @param roue Roue a laquelle apliquer le sens de la rotation
   * @param direction Sens de rotation de la roue
   */
  void ajusterDirection(Roue::Roue roue, Direction::Direction direction);

#endif // !PULSE_WIDTH_MODULATION_H
