#ifndef SETTINGS_H
#define SETTINGS_H

#define F_CPU 8000000L
#include <util/delay.h>
#include <util/delay_basic.h>
#include <avr/io.h>
#include <avr/interrupt.h>
#include <math.h>
#include <stdint.h>
#include <util/twi.h>

//1 -> output
//0 -> input

//PA0 en input pour le senseur de distance
//PA1 libre
//PA2 en output pour la calibration du senseur de ligne
//PA3 en input pour le capteur 5 du senseur de ligne
//PA4 en input pour le capteur 4 du senseur de ligne
//PA5 en input pour le capteur 3 du senseur de ligne
//PA6 en input pour le capteur 2 du senseur de ligne
//PA7 en input pour le capteur 1 du senseur de ligne
#define PA 0x00

//PB0 en output pour la Dell
//PB1 en output pour la Dell
//PB2 en input pour le OUT du capteur de couleur
//PB3 en input pour le LED du capteur de couleur
//PB4 en output pour la sortie active du haut-parleur
//PB5 en output pour la sortie à 0 du haut-parleur
//PB6 en output pour le S2 du capteur de couleur
//PB7 en output pour le S3 du capteur de couleur
#define PB 0xf3

//PC0 libre
//PC1 libre
//PC2 libre
//PC3 libre
//PC4 libre
//PC5 libre
//PC6 libre
//PC7 libre
#define PC 0xff

//PD0 en output pour le S0 du capteur de couleur
//PD1 en output pour le S1 du capteur de couleur
//PD2 libre
//PD3 en input pour le boutton poussoir
//PD4 en output pour la dirrection de la roue gauche
//PD5 en output pour la dirrection de la roue droite
//PD6 en output pour le output enable du moteur gauche
//PD7 en output pour le output enable du moteur droit
#define PD 0xf1

#define VITESSES_INITIALES 0xc7

#endif // ! SETTINGS_H
