#include "Forme.h"

/* ===OBJECT DEFAULT CONSTRUCTORS/DESTRUCTORS=== */
Forme::Forme() {
  nData_ = 0;
  samplesPerData_ = 1;
  tCounter_ = 0;
}

Forme::~Forme() {

}


/* ===MAIN PROGRAM METHODS=== */
// Returns the distance to obstacle in centimeters
float Forme::getDistanceCm() {
  return convertVoltageToCm(getVoltageRatio());
}

// Returns the shape of the room
Piece::Piece Forme::getShape() {

  uint16_t squareScore = getSquareScore();
  if (squareScore > nData_/40) {
    return Piece::CARRE;
  }
  else {
    int8_t score = getCircleVsOctagon();
    if (score > 3) {
      return Piece::OCTOGONE;
    }
    else {
      return Piece::CERCLE;
    }
  }
}

// Resets the data attributes of the object
void Forme::reset() {
	nData_ = 0;
  samplesPerData_ = 1;
  tCounter_ = 0;
}


/* ===DATA PROCESSING METHODS===*/
// Returns the number of data points above a certain threshold used to identify square room
uint16_t Forme::getSquareScore() {
  uint16_t squareCounter = 0;

  for (uint16_t i = 0; i < nData_/2; i++) {
    if (convertVoltageToCm(sample_[i]) > 23) {
      squareCounter++;
    }
  }
  return squareCounter;
}

// Returns the variance of the room, a lower variance indicates a circle, while a bigger variance is an octagon
int8_t Forme::getCircleVsOctagon() {
  uint16_t interval = nData_/2;
  uint16_t offset = nData_/5;
  int16_t min = 255;
  int16_t max = 0;

  uint16_t midpoint = interval;
  uint16_t lowpoint = midpoint - offset;
  uint16_t highpoint = midpoint + offset;
  for (uint16_t j = lowpoint; j < highpoint; j++) {
    int16_t value = convertVoltageToCm(sample_[j]);
    if (value < min) {
      min = value;
    }
    if (value > max) {
      max = value;
    }
  }

  return max - min;
}


/* ===DATA COLLECTION METHODS=== */
// Collect a data point from the sensor, and add it to the temporary table. If there are enough points in the temporary table to compress, then compress using compressSamples(), and add to main table
bool Forme::addSample() {
  if (samplesPerData_ >= 16) {
    return false;
  }
  if (nData_ >= 200) {
    compressSamples();
  }

  tempSample_[tCounter_] = getVoltageRatio();

  if (tCounter_ < samplesPerData_ - 1) {
    tCounter_++;
  }
  else {
    sample_[nData_] = averageCompressed();
    nData_++;
    tCounter_ = 0;
  }

  return true;
}

// Compress samples before adding to main table at ratio of samplesPerData_ to 1
void Forme::compressSamples() {
  for (uint8_t i = 0; i < 100; i++) {
    sample_[i] = (sample_[2*i] + sample_[2*i + 1])/2;
  }
  nData_ = 100;
  samplesPerData_ *= 2;
}

// Average of raw data, we compress by taking averages
uint16_t Forme::averageCompressed() {
  uint16_t sum = 0;
  for (uint8_t i = 0; i < samplesPerData_; i++) {
    sum += tempSample_[i];
  }
  return sum / samplesPerData_;
}

// Get the distance from sensor in the form of a uint8_t [0 to 255]
uint8_t Forme::getVoltageRatio() {
	return converter.lecture(0) >> 2;
}

// Convert uint8_t voltage ratio distance to centimeters
float Forme::convertVoltageToCm(uint8_t voltageRatio) {
  return float(pow(voltageRatio, -1.288) * 11419); // voir courbe de voltage vs. distance dans la documentation
}
