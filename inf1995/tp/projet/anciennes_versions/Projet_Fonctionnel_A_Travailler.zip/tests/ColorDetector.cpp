#include "ColorDetector.h"

ColorDetector::ColorDetector() {
	currentFilter_ = CLEAR;
	verifiedColor_ = Color::WHITE;
	bufferColor_ = Color::WHITE;

	clearFilterFrequency_ = 0;
	redFilterFrequency_ = 0;
	greenFilterFrequency_ = 0;
	blueFilterFrequency_ = 0;

	calibrationFrequency_ = 0;
}

ColorDetector::~ColorDetector() {

}

void ColorDetector::setSensorFilter() {
	switch (currentFilter_){
	case RED:
		PORTC &= ~(1 << 2); // s2 = 0
		PORTC &= ~(1 << 3); // s3 = 0
		break;
	case GREEN:
		PORTC |= (1 << 2); // s2 = 1
		PORTC |= (1 << 3); // s3 = 1
		break;
	case BLUE:
		PORTC &= ~(1 << 2); // s2 = 0
		PORTC |= (1 << 3); // s3 = 1
		break;
	case CLEAR:
		PORTC |= (1 << 2); // s2 = 1
		PORTC &= ~(1 << 3); // s3 = 0
		break;
	}
}

void ColorDetector::nextFilter() {
	switch (currentFilter_) {
		case CLEAR: {
			currentFilter_ = GREEN;
			break;
		}
		case RED: {
			currentFilter_ = BLUE;
			break;
		}
		case GREEN: {
			currentFilter_ = RED;
			break;
		}
		case BLUE: {
			currentFilter_ = CLEAR;
		}
	}
}

void ColorDetector::setFilterFrequency(uint16_t nCycles) {
	switch (currentFilter_) {
		case CLEAR: {
			clearFilterFrequency_ = nCycles;
			break;
		}
		case RED: {
			redFilterFrequency_ = nCycles;
			break;
		}
		case GREEN: {
			greenFilterFrequency_ = nCycles;
			break;
		}
		case BLUE: {
			blueFilterFrequency_ = nCycles;
		}
	}
}

void ColorDetector::addSample(uint16_t nCycles) {
	transmissionUART(nCycles >> 4);
	setFilterFrequency(nCycles);
	if (currentFilter_ == BLUE) {
		updateColor();
	}

	nextFilter();
	setSensorFilter();
}

Color::Color ColorDetector::getColor() {
	return verifiedColor_;
}

void ColorDetector::updateColor() {

	Color::Color foundColor = colorAlgorithm();

	//if (foundColor == bufferColor_) {
		verifiedColor_ = foundColor;
	//}
	bufferColor_ = foundColor;
}

Color::Color ColorDetector::colorAlgorithm() {
	if (clearFilterFrequency_ > calibrationFrequency_ * 0.5) {
		return Color::WHITE;
  }
  else if (redFilterFrequency_ > blueFilterFrequency_ && redFilterFrequency_ > greenFilterFrequency_) {
		return Color::RED;
	}
  else if (greenFilterFrequency_ >= blueFilterFrequency_) {
    return Color::GREEN;
  }
  else {
    return Color::BLUE;
  }
}

void ColorDetector::calibrateFrequency(uint16_t nCycles) {
	currentFilter_ = CLEAR;
	setSensorFilter();
	calibrationFrequency_ = nCycles;
}
