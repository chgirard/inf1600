#include "SuiveurDeLigne.h"
#include "lib_dir/Dell.h"


bool isDetecting(Capteur::Capteur capteur) {
  return PINA & capteur;
}

// VITESSES_INITIALES = 160 ou 0xa0
SuiveurDeLigne::SuiveurDeLigne() : isOnLine(true), rotationStage(5), vitesseNormeDroite(
  VITESSES_INITIALES), vitesseNormeGauche(VITESSES_INITIALES), vitesseDroite(
    VITESSES_INITIALES), vitesseGauche(VITESSES_INITIALES){
  isOnLine = true;
  rotationStage = 5;
}

SuiveurDeLigne::~SuiveurDeLigne() {}

void SuiveurDeLigne::init() {
  ajusterPWM(0x90, Direction::Avancer);
}

bool SuiveurDeLigne::suivreLigne() {

  ajusterVitesse(100);

  uint8_t nbCapteurDetect = 0;
  if (isDetecting(Capteur::EXTREME_GAUCHE))
    nbCapteurDetect++;
  if (isDetecting(Capteur::GAUCHE))
    nbCapteurDetect++;
  if (isDetecting(Capteur::CENTRE))
    nbCapteurDetect++;
  if (isDetecting(Capteur::DROITE))
    nbCapteurDetect++;
  if (isDetecting(Capteur::EXTREME_DROITE))
    nbCapteurDetect++;

  return nbCapteurDetect >= 3;
}

bool SuiveurDeLigne::suivreLigne(uint8_t distanceToWall) {
  if (distanceToWall - 19 < 5)
  {
    ajusterVitesse(((distanceToWall - 19) * 3 ) + 85);
  }
  else
  {
    ajusterVitesse(100);
  }

  return distanceToWall < 21;
}

void SuiveurDeLigne::ajusterVitesse(uint8_t pourcentage) {

  if (isDetecting(Capteur::CENTRE))
  {
    isOnLine = true;
    vitesseDroite = vitesseNormeDroite;
    vitesseGauche = vitesseNormeGauche;

  } else if (isDetecting(Capteur::GAUCHE)) {

    if (isOnLine) {
      isOnLine = false;

      if (vitesseNormeDroite < VITESSES_INITIALES + 0x20) {
        vitesseNormeDroite += 3;
      }
    }

    if ((vitesseDroite < VITESSES_INITIALES + 0x40) && (vitesseDroite < 0xff)) {
      vitesseDroite += 1;
    }

  } else if (isDetecting(Capteur::DROITE)) {

    if (isOnLine) {
      isOnLine = false;

      if (vitesseNormeDroite > VITESSES_INITIALES - 0x20) {
        vitesseNormeDroite -= 4;
      }

    }

    if ((vitesseDroite > VITESSES_INITIALES - 0x40) && (vitesseDroite > 0x50)) {
      vitesseDroite -= 1;
    }

  } else if (isDetecting(Capteur::EXTREME_GAUCHE)) {

      ajusterPWM(0x00, Direction::Avancer);
      _delay_ms(200);
    while (isDetecting(Capteur::EXTREME_GAUCHE) || !isDetecting(Capteur::GAUCHE)) {
      ajusterPWM(0x00, ajusterValeur(VITESSES_INITIALES, 80), Direction::Avancer);
      _delay_ms(5);
    }
      ajusterPWM(0x00, Direction::Avancer);
      _delay_ms(200);

  } else if (isDetecting(Capteur::EXTREME_DROITE)) {

      ajusterPWM(0x00, Direction::Avancer);
      _delay_ms(200);

    while (isDetecting(Capteur::EXTREME_DROITE) | !isDetecting(Capteur::DROITE)) {
      ajusterPWM(ajusterValeur(VITESSES_INITIALES, 80), 0x00, Direction::Avancer);
      _delay_ms(5);
    }
      ajusterPWM(0x00, Direction::Avancer);
      _delay_ms(200);

  }

  ajusterPWM(ajusterValeur(vitesseGauche, pourcentage), ajusterValeur(vitesseDroite, pourcentage), Direction::Avancer);
}

bool SuiveurDeLigne::uTurn() {
  bool returnValue = false;
  if (rotationStage == 0) {
    rotationStage = 5;
  }

  switch (rotationStage) {

    case 5:
    {
      ajusterPWM(ajusterValeur(VITESSES_INITIALES, 80), Direction::Avancer, Direction::Reculer);

      if (isDetecting(Capteur::EXTREME_GAUCHE)) {
        rotationStage--;

      }
    }
    break;

    case 4:
    {
      ajusterPWM(ajusterValeur(VITESSES_INITIALES, 80), Direction::Reculer, Direction::Avancer);

      if (isDetecting(Capteur::CENTRE)) {
        rotationStage--;
      }
    }
    break;

    case 3:
    {
      ajusterPWM(ajusterValeur(VITESSES_INITIALES, 80), Direction::Reculer, Direction::Avancer);

      if (isDetecting(Capteur::EXTREME_GAUCHE)) {
        rotationStage--;
      }
    }
    break;

    case 2:
    {
      ajusterPWM(ajusterValeur(VITESSES_INITIALES, 80), Direction::Reculer, Direction::Avancer);

      if (isDetecting(Capteur::CENTRE)) {
        rotationStage--;
        returnValue = true;
      }
    }
    break;

    case 1:
    {

      if (isDetecting(Capteur::GAUCHE)) {
        ajusterPWM(0x00, Direction::Avancer);
        rotationStage--;
        returnValue = true;
      } else {
        ajusterPWM(ajusterValeur(VITESSES_INITIALES, 70), Direction::Avancer, Direction::Reculer);
      }

    }
    break;
  }

  return returnValue;

}

void SuiveurDeLigne::rTurn() {

  ajusterPWM(vitesseNormeGauche, vitesseNormeDroite, Direction::Avancer);
  _delay_ms(1000);

  while (!isDetecting(Capteur::EXTREME_DROITE)) {
    ajusterPWM(VITESSES_INITIALES, Direction::Avancer, Direction::Reculer);
    _delay_ms(5);
  }

  while (!isDetecting(Capteur::GAUCHE)) {
    ajusterPWM(ajusterValeur(VITESSES_INITIALES, 60), Direction::Avancer, Direction::Reculer);
    _delay_ms(5);
  }

  while (!isDetecting(Capteur::DROITE)) {
    ajusterPWM(ajusterValeur(VITESSES_INITIALES, 70), Direction::Reculer, Direction::Avancer);
    _delay_ms(5);
  }

  ajusterPWM(0x00, Direction::Avancer);
  _delay_ms(300);

}

void SuiveurDeLigne::lTurn() {

    ajusterPWM(vitesseNormeGauche, vitesseNormeDroite, Direction::Avancer);
    _delay_ms(1000);

  while (!isDetecting(Capteur::EXTREME_GAUCHE)) {
    ajusterPWM(VITESSES_INITIALES, Direction::Reculer, Direction::Avancer);
    _delay_ms(5);
  }

  while (!isDetecting(Capteur::DROITE)) {
    ajusterPWM(ajusterValeur(VITESSES_INITIALES, 60), Direction::Reculer, Direction::Avancer);
    _delay_ms(5);
  }

  while (!isDetecting(Capteur::GAUCHE)) {
    ajusterPWM(ajusterValeur(VITESSES_INITIALES, 70), Direction::Avancer, Direction::Reculer);
    _delay_ms(5);
  }

  ajusterPWM(0x00, Direction::Avancer);
  _delay_ms(300);

}

void SuiveurDeLigne::arreter() {
  ajusterPWM(0, Direction::Reculer);
}
