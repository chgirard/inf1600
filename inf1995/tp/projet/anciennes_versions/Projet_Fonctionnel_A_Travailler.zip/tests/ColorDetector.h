#ifndef COLORDETECTOR_H
#define COLORDETECTOR_H

#include "lib_dir/Settings.h"
#include "lib_dir/Util.h"
#include "Color.h"

class ColorDetector {

public:

	ColorDetector();
	~ColorDetector();

	void setSensorFilter();
	void nextFilter();
	void setFilterFrequency(uint16_t nCycles);

	void addSample(uint16_t nCycles);
 	Color::Color getColor();
	void updateColor();
	Color::Color colorAlgorithm();

	void calibrateFrequency(uint16_t nCycles);

private:
	enum Filter {
		CLEAR, RED, GREEN, BLUE
	};

	Filter currentFilter_;
	Color::Color verifiedColor_;
	Color::Color bufferColor_;

	uint16_t clearFilterFrequency_;
	uint16_t redFilterFrequency_;
	uint16_t greenFilterFrequency_;
	uint16_t blueFilterFrequency_;

	uint16_t calibrationFrequency_;
};


#endif /* ColorDetector_h */
