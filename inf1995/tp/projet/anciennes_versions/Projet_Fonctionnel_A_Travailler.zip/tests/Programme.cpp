#include "lib_dir/Settings.h"
#include "lib_dir/Util.h"
#include "lib_dir/Minuterie.h"
#include "lib_dir/PulseWidthModulation.h"
#include "lib_dir/Dell.h"
#include "lib_dir/ControleurCouleurs.h"
#include "SuiveurDeLigne.h"
#include "Forme.h"



//              | VERT | BLANC | BLEU | ROUGE  <-filtres
// sur le blanc |   56 |   194 |   62 |    46
// sur le rouge |   07 |    54 |    6 |    35
// sur le bleu  |   07 |    32 |   20 |    04
// sur le vert  |   14 |    36 |   13 |     6
// surfaces ^


//White = 60|61
//Red = 5|6
//Green = 14|15
//Blue = 19|20
//Black = 1|2

//RED Filter
//White = 47|48
//Red = 34|35
//Green = 6|7
//Blue = 4|5
//Black = 0|1

//RED Filter
//White = 46|47
//Red = 34|35
//Green = 6|7
//Blue = 4|5
//Black = 0|1

volatile bool tick = false;
volatile int nCycles = 0;
//1 octogone rouge
//2 cercle Vert
//3 carre bleu

/*
* LIGNE_ALLER: Se rendre à la prochaine pièce
* LIGNE_RETOUR: Rentrer dans la pièce, prendre les données de la pièce, puis sortir
* DETECTER_PIECE: Après avoir pris toutes les données des trois pièces, de revenir et détecter les couleurs
*/
enum Etats {
  FINI, LIGNE_ALLER, LIGNE_RETOUR, DETECTER_PIECE_ALLER, DETECTER_PIECE_RETOUR, DETECTER_PIECE_DONNES, DETECTER_PIECE_AJUSTEMENT_LIGNE, DETECTER_PIECE_CALIBRATION
};

// Minuterie au 5 millisecondes
ISR(TIMER1_COMPA_vect){
  tick = true;
}


ISR(INT0_vect){
	nCycles++;
}

int main()
{
  // Set les ports
  initialisation();

  // minuterie 1 au 5 millisecondes
  initialiserMinuterie(5);

  Etats etat = LIGNE_ALLER;

  Piece::Piece suitePiece[3] = {Piece::UNKNOWN, Piece::UNKNOWN, Piece::UNKNOWN};// Rouge vert bleu

  // Contrôleur pour suivre les lignes
  SuiveurDeLigne ligneux;
  Forme forme;
  ControleurCouleurs controleurCouleurs;
  uint8_t noPiece = 0;

  // Delay to not turn right (300 * 5 millisecondes = 1.5 secondes)
  uint32_t delay = 0;

	//Pour ne créer le controleur de couleurs qu'un fois.

	uint16_t filterFrequencies[4];
	uint8_t filterCounter = 0;
  uint8_t wasClear = 0, wasRed = 0, wasBlue = 0, wasGreen = 0;

  uint8_t room[3];
  uint8_t colorPattern[3];
  uint8_t previousColour = 0;
  uint8_t colorCounter = 0;


// DO NOT REMOVE, VERY IMPORTANT FOR CALIBRATION
// CALIBRATE AT TURN RED AT 11 CM
// CHECK CHANGE EVERY 2 CM
/*  while(true){
uint8_t v = forme.getDistanceCm();
if(v<10 || v > 40)
setLight(Couleur::Eteint);
else if((v/2)%2==0)
setLight(Couleur::Vert);
else
setLight(Couleur::Rouge);


  }*/


  while (true) {
    // À chaque 5 millisecondes, la boucle va exécuter
    if (tick) {
      tick = false;

      delay++;

      switch (etat) {
        case LIGNE_ALLER: {


          // delay was initialized at 0, so it takes 5 * 300 milliseconds (1.5 seconds) to reach 300
          // ligneur.suivreLigne() is true when it detects an intersection
          if (ligneux.suivreLigne() && (delay > 300)) {

            ligneux.rTurn();
            etat = DETECTER_PIECE_ALLER;
            delay = 0;
          }
        }

        break;

        case DETECTER_PIECE_ALLER: {

          float distanceToWall = forme.getDistanceCm();
          if (ligneux.suivreLigne(distanceToWall)) {
            if (delay > 100) {
              etat = DETECTER_PIECE_DONNES;
              forme.reset();
            }
          }

        }
        break;

        case DETECTER_PIECE_CALIBRATION: {

          if (ligneux.uTurn())
          {
            etat = DETECTER_PIECE_DONNES;
          }

        }

        case DETECTER_PIECE_DONNES: {

          forme.addSample();
          if (ligneux.uTurn())
          {
            etat = DETECTER_PIECE_AJUSTEMENT_LIGNE;
          }

        }
        break;

        case DETECTER_PIECE_AJUSTEMENT_LIGNE: {

          if (ligneux.uTurn())
          {
            etat = DETECTER_PIECE_RETOUR;

            suitePiece[noPiece] = forme.getShape();
            switch (suitePiece[noPiece]) {
              case Piece::CERCLE:

              setLight(Couleur::Vert);
              room[noPiece] = 1;

              break;
              case Piece::CARRE:


              soundOn(69);
              room[noPiece] = 2;

              break;
              case Piece::OCTOGONE:


              setLight(Couleur::Rouge);
              room[noPiece] = 3;

              break;
              default:

              break;
            }

            _delay_ms(2000);
            setLight(Couleur::Eteint);
            soundOff();

            noPiece++;

          }

        }
        break;

        case DETECTER_PIECE_RETOUR: {

          if (ligneux.suivreLigne()) {

            if (noPiece < 3) {
              ligneux.rTurn();
              etat = LIGNE_ALLER;
            } else {
              ligneux.lTurn();
              etat = LIGNE_RETOUR;
              PORTD |= 1;
            }
          }

        }
        break;

        case LIGNE_RETOUR: {
          /*
			if (ControleurCree = false){
				ControleurCree = true;
				ControleurCouleurs controleurCouleurs();
			}
          if (!controleurCouleurs.comparerSuites()){
            controleurCouleurs.detecterCouleur(nCycles);
            nCycles = 0;

            ligneux.suivreLigne();
          }
          else {
            return 0;
          }
*/

      ligneux.suivreLigne();

			filterFrequencies[filterCounter] = nCycles;
						filterCounter++;
						if (filterCounter == 4) {
							if (filterFrequencies[0] > 100) {
								if (wasClear >= 10) {
								  setLight(Couleur::Eteint);
  								soundOff();
                  if (previousColour != 0) {
                    previousColour = 0;
                  }
								}
                else {
                  wasClear++;
                  wasRed = 0;
                  wasBlue = 0;
                  wasGreen = 0;
                }
						  }
						  else if (filterFrequencies[1] > filterFrequencies[3] && filterFrequencies[1] > filterFrequencies[2]) {
						      if (wasRed == 5) {
                    setLight(Couleur::Rouge);
  									soundOff();
                    if (previousColour != 3) {
                      colorPattern[colorCounter] = 3;
                      colorCounter++;
                      previousColour = 3;
                    }
						      }
                  else if (wasRed < 5){
                    wasClear = 0;
                    wasRed++;
                    wasBlue = 0;
                    wasGreen = 0;
                  }
						  }
						  else if (filterFrequencies[2] >= filterFrequencies[3]) {
						      if (wasGreen == 5) {
                    setLight(Couleur::Vert);
  									soundOff();
                    if (previousColour != 1) {
                      colorPattern[colorCounter] = 1;
                      colorCounter++;
                      previousColour = 1;
                    }
						      }
                  else if (wasGreen < 5){
                    wasClear = 0;
                    wasRed = 0;
                    wasBlue = 0;
                    wasGreen++;
                  }
						  }
						  else {
						    	if (wasBlue == 5) {
                    soundOn(69);
  									setLight(Couleur::Eteint);
                    if (previousColour != 2) {
                      colorPattern[colorCounter] = 2;
                      colorCounter++;
                      previousColour = 2;
                    }
						    	}
                  else if (wasBlue < 5) {
                    wasClear = 0;
                    wasRed = 0;
                    wasBlue++;
                    wasGreen = 0;
                  }
						    }
							filterCounter = 0;
						}

            /* STOP ENGINES */
            if (colorCounter == 3) {
              uint8_t foundPattern = 0;
              transmissionUART(colorPattern[2]);
              if (room[0] == colorPattern[2]) {
                foundPattern++;
              }
              transmissionUART(colorPattern[1]);
              if (room[1] == colorPattern[1]) {
                foundPattern++;
              }
              transmissionUART(colorPattern[0]);
              if (room[2] == colorPattern[0]) {
                foundPattern++;
              }
              if (foundPattern == 3) {
                etat = FINI;
              }
              else {
                colorCounter = 0;
              }
            }



			//controleurCouleurs.tick(nCycles);
			controleurCouleurs.incrementerFiltre();
			nCycles = 0;



        }

        break;

        case FINI:

        ligneux.arreter();

        break;

      }
    }
  }
  while (true) {
    /* code */
  }
  return 0;
}
