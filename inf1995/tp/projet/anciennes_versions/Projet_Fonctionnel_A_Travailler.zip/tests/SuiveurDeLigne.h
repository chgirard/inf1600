#ifndef SUIVEURDELIGNE_H
#define SUIVEURDELIGNE_H

  #include "lib_dir/Settings.h"
  #include "lib_dir/PulseWidthModulation.h"
  #include "lib_dir/Util.h"

  namespace Capteur {
    enum Capteur {
      EXTREME_GAUCHE = 0x80, GAUCHE = 0x40, CENTRE = 0x20, DROITE = 0x10, EXTREME_DROITE = 0x08
    };
  }

  bool isDetecting(Capteur::Capteur capteur);

  class SuiveurDeLigne {

  public:
    SuiveurDeLigne();
    ~SuiveurDeLigne();

    void init();
    bool suivreLigne();
    bool suivreLigne(uint8_t distanceToWall);
    bool uTurn();

    void rTurn();
    void lTurn();

    void arreter();

  private:
    void ajusterVitesse(uint8_t pourcentage);

    bool isOnLine; // true quand capteur C3 détecte ligne
    uint8_t rotationStage;

    uint8_t vitesseNormeDroite;
    uint8_t vitesseNormeGauche;
    uint8_t vitesseDroite;
    uint8_t vitesseGauche;

  };

#endif // ! SUIVEURDELIGNE_H
