#ifndef PIECES_H
#define PIECES_H

namespace Piece {
  enum Piece {
    CARRE = 3, CERCLE = 2, OCTOGONE = 1, UNKNOWN = 0
  };
}

#endif /* Pieces_h */
